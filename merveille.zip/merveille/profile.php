<?php

include "auth.php";

require_once "database.php";


$db=new Database();

$conn=$db->connect();



$id=$_SESSION['user']['id'];



$stmt=$conn->prepare(

"SELECT * FROM users WHERE id=?"

);


$stmt->execute([$id]);


$user=$stmt->fetch(PDO::FETCH_ASSOC);


?>


<!DOCTYPE html>

<html>

<head>

<title>Mon profil</title>

<link rel="stylesheet" href="style.css">

</head>


<body>


<?php include "navbar.php"; ?>



<div class="card" style="width:500px;margin:50px auto;">


<h2>

Mon profil

</h2>


<p>

Nom :

<?= $user['fullname']; ?>

</p>



<p>

Email :

<?= $user['email']; ?>

</p>



<p>

Téléphone :

<?= $user['phone']; ?>

</p>



<a class="btn-primary"

href="dashboard.php">

Retour

</a>


</div>



<?php include "footer.php"; ?>


</body>

</html>