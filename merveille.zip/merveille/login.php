<?php





require_once "database.php";


$message="";


if(isset($_POST['login'])){


$email=$_POST['email'];

$password=$_POST['password'];



$db=new Database();

$conn=$db->connect();



$query=$conn->prepare(

"SELECT * FROM users WHERE email=?"

);


$query->execute([$email]);



$user=$query->fetch(PDO::FETCH_ASSOC);



if($user && password_verify($password,$user['password'])){


$_SESSION['user']=$user;


header("Location:dashboard.php");


}

else{


$message="Email ou mot de passe incorrect";


}


}


?>



<!DOCTYPE html>

<html>

<head>

<title>Connexion</title>

<link rel="stylesheet" href="style.css">

</head>



<body>


<?php include "navbar.php"; ?>



<div class="card" style="width:400px;margin:50px auto;">


<h2>
Connexion
</h2>


<p>
<?= $message ?>
</p>



<form method="POST">


<input 
class="form-control"
type="email"
name="email"
placeholder="Email"
required>



<input 
class="form-control"
type="password"
name="password"
placeholder="Mot de passe"
required>



<button 
class="btn-primary"
name="login">

Connexion

</button>



</form>



<p>

Pas encore inscrit ?

<a href="register.php">
Créer un compte
</a>

</p>


</div>



<?php include "footer.php"; ?>


</body>

</html>