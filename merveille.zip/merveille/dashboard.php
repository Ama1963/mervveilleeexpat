<?php

include "auth.php";

?>

<?php

include "auth.php";

require_once "database.php";


$db=new Database();

$conn=$db->connect();



$stmt=$conn->prepare(

"SELECT * FROM products WHERE user_id=?"

);


$stmt->execute([$_SESSION['user']['id']]);


$products=$stmt->fetchAll(PDO::FETCH_ASSOC);


?>
<h2>Mes annonces</h2>

<?php foreach($products as $p){ ?>

<div class="card">

<h3><?=$p['title']?></h3>

<p><?=$p['price']?> FCFA</p>

<a href="edit_product.php?id=<?=$p['id']?>">
Modifier
</a>

<a href="delete_product.php?id=<?=$p['id']?>">
Supprimer
</a>

</div>

<?php } ?>