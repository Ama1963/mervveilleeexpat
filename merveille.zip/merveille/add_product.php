<?php

include "auth.php";


require_once "database.php";



$message="";



if(isset($_POST['save'])){


$title=$_POST['title'];

$description=$_POST['description'];

$price=$_POST['price'];

$category=$_POST['category'];



$image=$_FILES['image']['name'];



$tmp=$_FILES['image']['tmp_name'];



move_uploaded_file(

$tmp,

"uploads/".$image

);



$db=new Database();

$conn=$db->connect();



$sql=$conn->prepare(

"INSERT INTO products

(user_id,category_id,title,description,price,image)

VALUES(?,?,?,?,?,?)"

);



$sql->execute([

$_SESSION['user']['id'],

$category,

$title,

$description,

$price,

$image

]);



$message="Produit publié avec succès";


}



?>


<!DOCTYPE html>

<html>

<head>

<title>Ajouter produit</title>

<link rel="stylesheet" href="style.css">

</head>


<body>


<?php include "navbar.php"; ?>



<div class="card" style="width:500px;margin:40px auto;">


<h2>

Publier une annonce

</h2>


<p>

<?= $message ?>

</p>



<form method="POST" enctype="multipart/form-data">



<input 
class="form-control"
name="title"
placeholder="Titre du produit"
required>



<textarea
class="form-control"
name="description"
placeholder="Description">

</textarea>



<input 
class="form-control"
type="number"
name="price"
placeholder="Prix FCFA"
required>



<select 
class="form-control"
name="category">


<option value="1">
Téléphones
</option>


<option value="2">
Ordinateurs
</option>


<option value="3">
Mode
</option>


<option value="4">
Immobilier
</option>


<option value="5">
Automobile
</option>


<option value="6">
Maison
</option>



</select>



<input 
class="form-control"
type="file"
name="image"
required>



<button 
class="btn-primary"
name="save">

Publier

</button>


</form>



</div>



<?php include "footer.php"; ?>


</body>

</html>