<?php

class Database{


private $host="localhost";

private $db="marketplace";

private $user="root";

private $password="";


public function connect(){


try{


$conn = new PDO(

"mysql:host=".$this->host.";dbname=".$this->db,

$this->user,

$this->password

);


$conn->setAttribute(

PDO::ATTR_ERRMODE,

PDO::ERRMODE_EXCEPTION

);


return $conn;


}

catch(PDOException $e){


die("Erreur connexion : ".$e->getMessage());


}


}


}
UPDATE users 
SET role='admin'
WHERE email='admin@marketplace.com';

INSERT INTO users
(fullname,email,phone,password,role)

VALUES

(
'Administrateur',
'sowamadou141@gmail.com',
'77 679 33 66',
'$2y$10$8FJx0uN0zq9wJ8JXJj0vEezVn8Jr6Z0P4jWq5f8P3uG9d5r2',
'admin'
);
?>