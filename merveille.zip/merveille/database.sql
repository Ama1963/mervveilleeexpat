CREATE DATABASE marketplace;

USE marketplace;


CREATE TABLE users(

id INT AUTO_INCREMENT PRIMARY KEY,

fullname VARCHAR(100) NOT NULL,

email VARCHAR(150) UNIQUE NOT NULL,

phone VARCHAR(20),

password VARCHAR(255) NOT NULL,

role ENUM('user','admin') DEFAULT 'user',

created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

);



CREATE TABLE categories(

id INT AUTO_INCREMENT PRIMARY KEY,

name VARCHAR(100) NOT NULL

);



INSERT INTO categories(name)
VALUES
('Téléphones'),
('Ordinateurs'),
('Mode'),
('Immobilier'),
('Automobile'),
('Maison');



CREATE TABLE products(

id INT AUTO_INCREMENT PRIMARY KEY,

user_id INT NOT NULL,

category_id INT NOT NULL,

title VARCHAR(200),

description TEXT,

price DECIMAL(10,2),

image VARCHAR(255),

created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,


FOREIGN KEY(user_id)
REFERENCES users(id)
ON DELETE CASCADE,


FOREIGN KEY(category_id)
REFERENCES categories(id)
ON DELETE CASCADE

);