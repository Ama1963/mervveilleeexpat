<footer class="footer">

<p>
© 2026 Marketplace - Tous droits réservés
</p>

</footer>