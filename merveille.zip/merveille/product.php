<?php


require_once "database.php";


$id=$_GET['id'];



$db=new Database();

$conn=$db->connect();



$stmt=$conn->prepare(

"SELECT products.*,users.fullname,users.phone

FROM products

JOIN users ON products.user_id=users.id

WHERE products.id=?"

);


$stmt->execute([$id]);


$product=$stmt->fetch(PDO::FETCH_ASSOC);



?>


<!DOCTYPE html>

<html>

<head>

<title><?= $product['title']; ?></title>

<link rel="stylesheet" href="style.css">

</head>


<body>


<?php include "navbar.php"; ?>



<div class="card" style="margin:50px;">


<img 

src="uploads/<?= $product['image']; ?>"

style="width:400px;">



<h1>

<?= $product['title']; ?>

</h1>


<h2>

<?= $product['price']; ?> FCFA

</h2>



<p>

<?= $product['description']; ?>

</p>



<h3>

Vendeur :

<?= $product['fullname']; ?>

</h3>



<p>

Téléphone :

<?= $product['phone']; ?>

</p>



</div>



<?php include "footer.php"; ?>


</body>

</html>