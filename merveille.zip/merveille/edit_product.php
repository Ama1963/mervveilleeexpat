<?php


include "auth.php";


require_once "database.php";


$db=new Database();

$conn=$db->connect();



$id=$_GET['id'];



$stmt=$conn->prepare(

"SELECT * FROM products WHERE id=?"

);


$stmt->execute([$id]);


$product=$stmt->fetch(PDO::FETCH_ASSOC);



if(isset($_POST['update'])){


$title=$_POST['title'];

$description=$_POST['description'];

$price=$_POST['price'];



$sql=$conn->prepare(

"UPDATE products SET title=?,description=?,price=? WHERE id=?"

);



$sql->execute([

$title,

$description,

$price,

$id

]);



header("Location:dashboard.php");


}


?>



<!DOCTYPE html>

<html>

<head>

<title>Modifier produit</title>

<link rel="stylesheet" href="style.css">

</head>


<body>


<?php include "navbar.php"; ?>


<div class="card" style="width:500px;margin:40px auto;">


<h2>

Modifier annonce

</h2>



<form method="POST">


<input

class="form-control"

name="title"

value="<?=$product['title']?>">



<textarea

class="form-control"

name="description">

<?=$product['description']?>

</textarea>



<input

class="form-control"

name="price"

value="<?=$product['price']?>">



<button

class="btn-primary"

name="update">

Modifier

</button>


</form>


</div>


</body>

</html>