<?php

require_once "database.php";


$message="";


if(isset($_POST['register'])){


$fullname=$_POST['fullname'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$password=$_POST['password'];
$confirm=$_POST['confirm'];


if($password != $confirm){

$message="Les mots de passe ne correspondent pas";

}

else{


$db = new Database();

$conn=$db->connect();



$check=$conn->prepare(

"SELECT id FROM users WHERE email=?"

);


$check->execute([$email]);


if($check->rowCount()>0){


$message="Cet email existe déjà";


}

else{


$hash=password_hash($password,PASSWORD_DEFAULT);


$sql=$conn->prepare(

"INSERT INTO users(fullname,email,phone,password)
VALUES(?,?,?,?)"

);



$sql->execute([

$fullname,

$email,

$phone,

$hash

]);



$message="Inscription réussie. Connectez-vous";


}



}



}

?>


<!DOCTYPE html>

<html>

<head>

<title>Inscription</title>

<link rel="stylesheet" href="style.css">

</head>


<body>


<?php include "navbar.php"; ?>



<div class="card" style="width:400px;margin:50px auto;">


<h2>
Créer un compte
</h2>


<p>
<?= $message ?>
</p>



<form method="POST">


<input class="form-control"
type="text"
name="fullname"
placeholder="Nom complet"
required>


<input class="form-control"
type="email"
name="email"
placeholder="Email"
required>



<input class="form-control"
type="text"
name="phone"
placeholder="Téléphone">



<input class="form-control"
type="password"
name="password"
placeholder="Mot de passe"
required>



<input class="form-control"
type="password"
name="confirm"
placeholder="Confirmer mot de passe"
required>



<button class="btn-primary"
name="register">

S'inscrire

</button>



</form>


<p>

Déjà un compte ?

<a href="login.php">
Connexion
</a>

</p>



</div>



<?php include "footer.php"; ?>


</body>

</html>