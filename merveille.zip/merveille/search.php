<?php

require_once "database.php";


$db=new Database();

$conn=$db->connect();



$q="";


if(isset($_GET['q'])){

$q=$_GET['q'];

}



$stmt=$conn->prepare(

"SELECT products.*,users.fullname,categories.name AS category

FROM products

JOIN users ON products.user_id=users.id

JOIN categories ON products.category_id=categories.id

WHERE title LIKE ?

OR description LIKE ?

ORDER BY id DESC"

);



$stmt->execute([

"%".$q."%",

"%".$q."%"

]);



$products=$stmt->fetchAll(PDO::FETCH_ASSOC);


?>



<!DOCTYPE html>

<html>

<head>

<title>Recherche</title>

<link rel="stylesheet" href="style.css">

</head>


<body>


<?php include "navbar.php"; ?>


<div style="padding:40px;">


<h2>

Résultat pour :

<?= $q ?>

</h2>



<div style="display:flex;gap:20px;flex-wrap:wrap;">



<?php foreach($products as $product){ ?>


<div class="card" style="width:280px;">


<img

src="uploads/<?= $product['image'];?>"

style="width:100%;height:180px;object-fit:cover;">



<h3>

<?= $product['title']; ?>

</h3>



<p>

<?= $product['price']; ?> FCFA

</p>



<a class="btn-primary"

href="product.php?id=<?=$product['id']?>">

Voir

</a>



</div>


<?php } ?>


</div>



</div>



<?php include "footer.php"; ?>


</body>

</html>