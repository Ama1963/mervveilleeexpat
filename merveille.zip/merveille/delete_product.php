<?php


include "auth.php";


require_once "database.php";



$db=new Database();

$conn=$db->connect();



$id=$_GET['id'];



$stmt=$conn->prepare(

"DELETE FROM products WHERE id=?"

);



$stmt->execute([$id]);



header("Location:dashboard.php");


?>