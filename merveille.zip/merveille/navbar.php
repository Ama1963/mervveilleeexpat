<?php

session_start();

?>


<nav class="navbar">


<span class="logo">
MarketPlace
</span>


<a href="index.php">
Accueil
</a>


<?php if(isset($_SESSION['user'])){ ?>


<a href="dashboard.php">
Tableau de bord
</a>


<a href="logout.php">
Déconnexion
</a>


<?php }else{ ?>


<a href="login.php">
Connexion
</a>


<a href="register.php">
Inscription
</a>


<?php } ?>


</nav>