<?php

require_once "database.php";


$db = new Database();

$conn=$db->connect();



$products=$conn->query(

"SELECT products.*, users.fullname, categories.name AS category

FROM products

JOIN users ON products.user_id=users.id

JOIN categories ON products.category_id=categories.id

ORDER BY products.id DESC"

)->fetchAll(PDO::FETCH_ASSOC);



?>


<!DOCTYPE html>

<html>

<head>

<title>Marketplace</title>

<link rel="stylesheet" href="style.css">

</head>


<body>


<?php include "navbar.php"; ?>


<div style="background:#061A40;color:white;padding:60px;text-align:center;">


<h1>

Achetez et vendez facilement

</h1>


<p>

La marketplace moderne pour vos achats

</p>


<form method="GET" action="search.php">


<input 
class="form-control"
style="width:300px;display:inline-block;"
name="q"
placeholder="Rechercher un produit">


<button class="btn-primary">

Rechercher

</button>


</form>


</div>




<div style="padding:40px;">


<h2>

Dernières annonces

</h2>


<div style="display:flex;gap:20px;flex-wrap:wrap;">



<?php foreach($products as $product){ ?>



<div class="card" style="width:280px;">



<img 

src="uploads/<?= $product['image']; ?>"

style="width:100%;height:180px;object-fit:cover;">



<h3>

<?= $product['title']; ?>

</h3>



<p>

<?= $product['price']; ?> FCFA

</p>


<p>

Catégorie :

<?= $product['category']; ?>

</p>


<a class="btn-primary"

href="product.php?id=<?= $product['id']; ?>">

Voir

</a>


</div>



<?php } ?>



</div>


</div>




<?php include "footer.php"; ?>


</body>

</html>